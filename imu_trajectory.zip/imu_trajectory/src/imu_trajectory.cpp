#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/PointStamped.h>
#include <visualization_msgs/Marker.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <yaml-cpp/yaml.h>
#include <fstream>
#include <string>
#include <cmath>
#include <deque>
#include <Eigen/Dense>
#include <Eigen/Geometry>

class ImuTrajectory
{
private:
    ros::NodeHandle nh_;
    ros::Subscriber imu_sub_;
    ros::Publisher marker_pub_;
    tf2_ros::TransformBroadcaster tf_broadcaster_;

    // IMU数据
    geometry_msgs::Point current_position_;
    tf2::Quaternion current_orientation_;
    geometry_msgs::Vector3 linear_velocity_;
    
    // IMU偏置 (直接从标定文件读取)
    geometry_msgs::Vector3 gyro_bias_;
    geometry_msgs::Vector3 accel_bias_;
    
    // 标定参数 (从yaml文件读取)
    double gyr_n_[3];  // 陀螺仪噪声密度 (x, y, z)
    double gyr_w_[3];  // 陀螺仪零偏不稳定性
    double acc_n_[3];  // 加速度计噪声密度
    double acc_w_[3];  // 加速度计零偏不稳定性
    
    // 滑动窗口滤波
    std::string filter_type_;  // 滤波器类型
    std::deque<geometry_msgs::Vector3> gyro_window_;  // 陀螺仪滑动窗口
    std::deque<geometry_msgs::Vector3> accel_window_; // 加速度计滑动窗口
    int window_size_;  // 滑动窗口大小
    std::string weight_type_;  // 权重类型 (等权重, 指数加权, 高斯权重)
    double gaussian_sigma_;     // 高斯滤波的标准差
    
    // ESKF参数
    // 状态向量：[位置(3), 速度(3), 姿态四元数(4), 陀螺仪偏置(3), 加速度计偏置(3)]
    // 误差状态向量：[位置误差(3), 速度误差(3), 姿态误差(3), 陀螺仪偏置误差(3), 加速度计偏置误差(3)]
    Eigen::MatrixXd P_;  // 误差状态协方差矩阵 (15x15)
    
    // 系统噪声协方差
    double q_bg_[3];  // 陀螺仪分轴偏置随机游走噪声
    double q_bb_[3];  // 加速度计分轴偏置随机游走噪声
    double q_gyr_[3];  // 陀螺仪分轴测量噪声
    double q_acc_[3];  // 加速度计分轴测量噪声
    
    // 测量噪声协方差
    double r_gyr_[3];  // 陀螺仪分轴测量噪声协方差
    double r_acc_[3];  // 加速度计分轴测量噪声协方差
    
    // 自适应噪声协方差调整参数
    double innovation_threshold_;  // 新息阈值
    double noise_update_factor_;  // 噪声增大因子
    double noise_reduce_factor_;  // 噪声减小因子
    
    // 配置文件参数
    std::string calibration_file_path_;  // IMU标定文件路径
    double time_interval_min_;  // 最小时间间隔
    double time_interval_max_;  // 最大时间间隔
    
    // 重力向量计算相关
    bool gravity_calculated_;  // 重力向量是否已计算完成
    int gravity_calibration_count_;  // 已收集的用于计算重力的帧数
    int gravity_calibration_samples_; // 需要的帧数
    geometry_msgs::Vector3 accel_sum_; // 加速度计读数总和
    double calculated_gravity_; // 计算出的重力值
    std::string gravity_mode_;   // 重力计算模式: auto(自动), manual(手动)
    double manual_gravity_;      // 手动设置的重力加速度值

    // 轨迹标记
    visualization_msgs::Marker trajectory_marker_;
    
    // 可视化标记发布者
    // ros::Publisher marker_pub_; // 已在第22行声明
    // 重力向量可视化发布者
    ros::Publisher gravity_vector_pub_;
    // 加速度向量可视化发布者
    ros::Publisher accel_vector_pub_;
    // 减去重力后的加速度向量可视化发布者
    ros::Publisher accel_vector_no_gravity_pub_;
    
    
    // 时间相关
    ros::Time last_time_;
    bool first_msg_received_;
    bool calibrated_;  // 是否已完成初始标定
    
    // 初始强制零速检测参数
    bool enable_initial_zupt_;        // 是否开启初始强制零速检测
    double initial_zupt_duration_;    // 初始强制零速检测持续时间（秒）
    ros::Time initial_zupt_start_time_;  // 初始强制零速检测开始时间
    bool is_in_initial_zupt_;         // 是否处于初始强制零速检测阶段
    
    // 普通零速检测（ZUPT）参数
  double zupt_accel_threshold_;     // 加速度阈值（x和y轴），小于此值认为处于零速
  double zupt_accel_z_threshold_;   // 加速度z轴与重力差值阈值，小于此值认为处于零速
  double zupt_gyro_threshold_;      // 角速度阈值，小于此值认为处于零速
  double zupt_cov_reduction_factor_; // 零速时ESKF速度误差协方差减小因子
  int consecutive_zupt_frames_;      // 连续零速帧数计数器
  int zupt_gravity_calibration_threshold_;  // 触发重力重新计算的连续零速帧数阈值

public:
    ImuTrajectory() : first_msg_received_(false), calibrated_(true), filter_type_("sliding_window"), window_size_(20),
                     weight_type_("equal"), gaussian_sigma_(1.0), gravity_calculated_(false), gravity_calibration_count_(0), gravity_calibration_samples_(100),
                     calculated_gravity_(9.81), gravity_mode_("auto"), manual_gravity_(9.80665), // 默认值，会被计算值或配置覆盖
                     // ESKF参数初始化（默认值，会被配置文件或标定文件覆盖）
                     innovation_threshold_(0.5), noise_update_factor_(1.1), noise_reduce_factor_(0.9),
                     time_interval_min_(0.0001), time_interval_max_(0.1),
                     calibration_file_path_("/home/ubuntu20/imu_traj_ws/src/imu_trajectory/IM42652_imu_param.yaml"),
                     // 初始强制零速检测参数
                     enable_initial_zupt_(false), initial_zupt_duration_(2.0), is_in_initial_zupt_(false),
                     // 普通零速检测（ZUPT）参数
                     zupt_accel_threshold_(0.1), zupt_accel_z_threshold_(0.1), zupt_gyro_threshold_(0.01), zupt_cov_reduction_factor_(0.1), consecutive_zupt_frames_(0), zupt_gravity_calibration_threshold_(50)
    {
        // 初始化位置和姿态
        current_position_.x = 0.0;
        current_position_.y = 0.0;
        current_position_.z = 0.0;
        current_orientation_.setRPY(0.0, 0.0, 0.0);
        linear_velocity_.x = 0.0;
        linear_velocity_.y = 0.0;
        linear_velocity_.z = 0.0;
        
        // 初始化加速度计总和
        accel_sum_.x = 0.0;
        accel_sum_.y = 0.0;
        accel_sum_.z = 0.0;
        
        // 初始化ESKF状态协方差矩阵 P_ (15x15)
        P_ = Eigen::MatrixXd::Zero(15, 15);
        // 默认协方差值
        double default_p0 = 1.0;
        double default_v0 = 0.1;
        double default_q0 = 0.01;
        double default_bg0 = 0.001;
        double default_bb0 = 0.01;
        // 位置协方差
        P_(0,0) = default_p0;
        P_(1,1) = default_p0;
        P_(2,2) = default_p0;
        // 速度协方差
        P_(3,3) = default_v0;
        P_(4,4) = default_v0;
        P_(5,5) = default_v0;
        // 姿态协方差
        P_(6,6) = default_q0;
        P_(7,7) = default_q0;
        P_(8,8) = default_q0;
        // 陀螺仪偏置协方差
        P_(9,9) = default_bg0;
        P_(10,10) = default_bg0;
        P_(11,11) = default_bg0;
        // 加速度计偏置协方差
        P_(12,12) = default_bb0;
        P_(13,13) = default_bb0;
        P_(14,14) = default_bb0;
        
        // 初始化分轴系统噪声数组
        q_gyr_[0] = q_gyr_[1] = q_gyr_[2] = 1e-3;
        q_bg_[0] = q_bg_[1] = q_bg_[2] = 1e-6;
        q_acc_[0] = q_acc_[1] = q_acc_[2] = 1e-2;
        q_bb_[0] = q_bb_[1] = q_bb_[2] = 1e-5;
        // 初始化分轴测量噪声数组
        r_gyr_[0] = r_gyr_[1] = r_gyr_[2] = 1e-3;
        r_acc_[0] = r_acc_[1] = r_acc_[2] = 1e-2;
        
        // 读取配置文件
        readConfig();
        
        // 读取IMU标定参数（如果文件存在）
        if (std::ifstream(calibration_file_path_.c_str()).good()) {
            readCalibrationParams();
        } else {
            ROS_WARN("Calibration file not found, using default ESKF parameters");
        }
        
        // 订阅IMU数据
        imu_sub_ = nh_.subscribe("/imu/data", 100, &ImuTrajectory::imuCallback, this);

        // 发布轨迹标记
        marker_pub_ = nh_.advertise<visualization_msgs::Marker>("imu_trajectory", 10);
        
        // 发布重力向量标记
        gravity_vector_pub_ = nh_.advertise<visualization_msgs::Marker>("gravity_vector", 10);
        // 发布加速度向量标记
        accel_vector_pub_ = nh_.advertise<visualization_msgs::Marker>("accel_vector", 10);
        // 发布减去重力后的加速度向量标记
        accel_vector_no_gravity_pub_ = nh_.advertise<visualization_msgs::Marker>("accel_vector_no_gravity", 10);

        
        // 初始化轨迹标记
        initTrajectoryMarker();
    }
    
    void readConfig()
    {
        // 读取配置文件
        std::string config_file = "/home/ubuntu20/imu_traj_ws/src/imu_trajectory/config.yaml";
        YAML::Node config = YAML::LoadFile(config_file);
        
        // 读取滤波器类型
        filter_type_ = config["filter_type"].as<std::string>();
        
        // 读取滑动窗口大小
        window_size_ = config["window_size"].as<int>();
        
        // 读取权重类型
        weight_type_ = config["weight_type"].as<std::string>();
        
        // 读取高斯滤波标准差
        gaussian_sigma_ = config["gaussian_sigma"].as<double>();
        
        // 读取ESKF参数
        // 状态协方差初始值
        double p0 = config["p0"].as<double>();
        double v0 = config["v0"].as<double>();
        double q0 = config["q0"].as<double>();
        double bg0 = config["bg0"].as<double>();
        double bb0 = config["bb0"].as<double>();
        
        // 自适应噪声协方差调整参数
        innovation_threshold_ = config["innovation_threshold"].as<double>();
        noise_update_factor_ = config["noise_update_factor"].as<double>();
        noise_reduce_factor_ = config["noise_reduce_factor"].as<double>();
        
        // 读取重力参数
        gravity_mode_ = config["gravity_mode"].as<std::string>();
        gravity_calibration_samples_ = config["gravity_calibration_samples"].as<int>();
        manual_gravity_ = config["manual_gravity"].as<double>();
        
        // 读取零速检测触发重力重新计算的阈值
  try {
    if (config["zupt_gravity_calibration_threshold"]) {
      zupt_gravity_calibration_threshold_ = config["zupt_gravity_calibration_threshold"].as<int>();
      ROS_INFO("ZUPT gravity calibration threshold: %d frames", zupt_gravity_calibration_threshold_);
    } else {
      zupt_gravity_calibration_threshold_ = 50; // 默认值
      ROS_INFO("Using default ZUPT gravity calibration threshold: %d frames", zupt_gravity_calibration_threshold_);
    }
  } catch (const YAML::Exception& e) {
    zupt_gravity_calibration_threshold_ = 50; // 默认值
    ROS_INFO("Using default ZUPT gravity calibration threshold: %d frames", zupt_gravity_calibration_threshold_);
  }
        
        // 读取标定文件路径
        calibration_file_path_ = config["calibration_file_path"].as<std::string>();
        
        // 读取时间间隔参数
        time_interval_min_ = config["time_interval_min"].as<double>();
        time_interval_max_ = config["time_interval_max"].as<double>();
        
        // 读取初始强制零速检测参数
        enable_initial_zupt_ = config["enable_initial_zupt"].as<bool>();
        initial_zupt_duration_ = config["initial_zupt_duration"].as<double>();
        
        // 读取普通零速检测（ZUPT）参数
        zupt_accel_threshold_ = config["zupt_accel_threshold"].as<double>();
        zupt_accel_z_threshold_ = config["zupt_accel_z_threshold"].as<double>();
        zupt_gyro_threshold_ = config["zupt_gyro_threshold"].as<double>();
        zupt_cov_reduction_factor_ = config["zupt_cov_reduction_factor"].as<double>();
        
        // 更新ESKF状态协方差矩阵
        P_ = Eigen::MatrixXd::Zero(15, 15);
        // 位置协方差
        P_(0,0) = p0;
        P_(1,1) = p0;
        P_(2,2) = p0;
        // 速度协方差
        P_(3,3) = v0;
        P_(4,4) = v0;
        P_(5,5) = v0;
        // 姿态协方差
        P_(6,6) = q0;
        P_(7,7) = q0;
        P_(8,8) = q0;
        // 陀螺仪偏置协方差
        P_(9,9) = bg0;
        P_(10,10) = bg0;
        P_(11,11) = bg0;
        // 加速度计偏置协方差
        P_(12,12) = bb0;
        P_(13,13) = bb0;
        P_(14,14) = bb0;
        
        // 读取系统噪声协方差（如果配置中存在，用于没有标定文件的情况）
        if (config["q_bg"]) {
            // 设置所有轴使用相同的噪声值（兼容原有配置）
            double q_bg = config["q_bg"].as<double>();
            double q_bb = config["q_bb"].as<double>();
            double q_gyr = config["q_gyr"].as<double>();
            double q_acc = config["q_acc"].as<double>();
            double r_gyr = config["r_gyr"].as<double>();
            double r_acc = config["r_acc"].as<double>();
            
            q_bg_[0] = q_bg_[1] = q_bg_[2] = q_bg;
            q_bb_[0] = q_bb_[1] = q_bb_[2] = q_bb;
            q_gyr_[0] = q_gyr_[1] = q_gyr_[2] = q_gyr;
            q_acc_[0] = q_acc_[1] = q_acc_[2] = q_acc;
            r_gyr_[0] = r_gyr_[1] = r_gyr_[2] = r_gyr;
            r_acc_[0] = r_acc_[1] = r_acc_[2] = r_acc;
        }
        
        ROS_INFO("Configuration loaded successfully");
        ROS_INFO("Filter type: %s", filter_type_.c_str());
        if (filter_type_ == "sliding_window") {
            ROS_INFO("Window size: %d", window_size_);
            ROS_INFO("Weight type: %s", weight_type_.c_str());
            if (weight_type_ == "gaussian") {
                ROS_INFO("Gaussian sigma: %.2f", gaussian_sigma_);
            }
        } else if (filter_type_ == "eskf") {
            ROS_INFO("ESKF parameters:");
            ROS_INFO("  State covariances: p0=%.6f, v0=%.6f, q0=%.6f, bg0=%.6f, bb0=%.6f", p0, v0, q0, bg0, bb0);
            ROS_INFO("  System noise (will be updated by calibration if available):");
        ROS_INFO("    q_gyr (x/y/z): %.6e, %.6e, %.6e", q_gyr_[0], q_gyr_[1], q_gyr_[2]);
        ROS_INFO("    q_bg (x/y/z): %.6e, %.6e, %.6e", q_bg_[0], q_bg_[1], q_bg_[2]);
        ROS_INFO("    q_acc (x/y/z): %.6e, %.6e, %.6e", q_acc_[0], q_acc_[1], q_acc_[2]);
        ROS_INFO("    q_bb (x/y/z): %.6e, %.6e, %.6e", q_bb_[0], q_bb_[1], q_bb_[2]);
            ROS_INFO("  Measurement noise (will be updated by calibration if available):");
              ROS_INFO("    r_gyr (x/y/z): %.6e, %.6e, %.6e", r_gyr_[0], r_gyr_[1], r_gyr_[2]);
              ROS_INFO("    r_acc (x/y/z): %.6e, %.6e, %.6e", r_acc_[0], r_acc_[1], r_acc_[2]);
            ROS_INFO("  Adaptive noise adjustment: threshold=%.2f, update=%.1f, reduce=%.1f", 
                     innovation_threshold_, noise_update_factor_, noise_reduce_factor_);
        }
        ROS_INFO("Gravity calibration samples: %d", gravity_calibration_samples_);
        ROS_INFO("Calibration file path: %s", calibration_file_path_.c_str());
    }
    
    void readCalibrationParams()
    {
        // 读取标定参数文件
        YAML::Node config = YAML::LoadFile(calibration_file_path_);
        
        // 读取陀螺仪参数
        gyr_n_[0] = config["Gyr"]["x-axis"]["gyr_n"].as<double>();
        gyr_n_[1] = config["Gyr"]["y-axis"]["gyr_n"].as<double>();
        gyr_n_[2] = config["Gyr"]["z-axis"]["gyr_n"].as<double>();
        
        gyr_w_[0] = config["Gyr"]["x-axis"]["gyr_w"].as<double>();
        gyr_w_[1] = config["Gyr"]["y-axis"]["gyr_w"].as<double>();
        gyr_w_[2] = config["Gyr"]["z-axis"]["gyr_w"].as<double>();
        
        // 读取加速度计参数
        acc_n_[0] = config["Acc"]["x-axis"]["acc_n"].as<double>();
        acc_n_[1] = config["Acc"]["y-axis"]["acc_n"].as<double>();
        acc_n_[2] = config["Acc"]["z-axis"]["acc_n"].as<double>();
        
        acc_w_[0] = config["Acc"]["x-axis"]["acc_w"].as<double>();
        acc_w_[1] = config["Acc"]["y-axis"]["acc_w"].as<double>();
        acc_w_[2] = config["Acc"]["z-axis"]["acc_w"].as<double>();
        
        // 使用分轴偏置
        gyro_bias_.x = config["Gyr"]["x-axis"]["gyr_w"].as<double>();
        gyro_bias_.y = config["Gyr"]["y-axis"]["gyr_w"].as<double>();
        gyro_bias_.z = config["Gyr"]["z-axis"]["gyr_w"].as<double>();
        
        accel_bias_.x = config["Acc"]["x-axis"]["acc_w"].as<double>();
        accel_bias_.y = config["Acc"]["y-axis"]["acc_w"].as<double>();
        accel_bias_.z = config["Acc"]["z-axis"]["acc_w"].as<double>();
        
        // 根据预标定数据自动调整ESKF参数
        if (filter_type_ == "eskf") {
            // 初始化分轴系统噪声协方差
            q_gyr_[0] = gyr_n_[0];
            q_gyr_[1] = gyr_n_[1];
            q_gyr_[2] = gyr_n_[2];
            q_bg_[0] = gyr_w_[0];
            q_bg_[1] = gyr_w_[1];
            q_bg_[2] = gyr_w_[2];
            q_acc_[0] = acc_n_[0];
            q_acc_[1] = acc_n_[1];
            q_acc_[2] = acc_n_[2];
            q_bb_[0] = acc_w_[0];
            q_bb_[1] = acc_w_[1];
            q_bb_[2] = acc_w_[2];
            // 初始化分轴测量噪声协方差
            r_gyr_[0] = gyr_n_[0];
            r_gyr_[1] = gyr_n_[1];
            r_gyr_[2] = gyr_n_[2];
            r_acc_[0] = acc_n_[0];
            r_acc_[1] = acc_n_[1];
            r_acc_[2] = acc_n_[2];

            ROS_INFO("ESKF parameters initialized with per-axis calibration data:");
            ROS_INFO("  Gyro noise density (x/y/z): %.6e, %.6e, %.6e", gyr_n_[0], gyr_n_[1], gyr_n_[2]);
            ROS_INFO("  Gyro bias instability (x/y/z): %.6e, %.6e, %.6e", gyr_w_[0], gyr_w_[1], gyr_w_[2]);
            ROS_INFO("  Accel noise density (x/y/z): %.6e, %.6e, %.6e", acc_n_[0], acc_n_[1], acc_n_[2]);
            ROS_INFO("  Accel bias instability (x/y/z): %.6e, %.6e, %.6e", acc_w_[0], acc_w_[1], acc_w_[2]);
        }
        
        ROS_INFO("IMU calibration parameters loaded successfully (per-axis)");
        ROS_INFO("Gyro bias: x=%.6f, y=%.6f, z=%.6f rad/s", 
                 gyro_bias_.x, gyro_bias_.y, gyro_bias_.z);
        ROS_INFO("Accel bias: x=%.6f, y=%.6f, z=%.6f m/s^2", 
                 accel_bias_.x, accel_bias_.y, accel_bias_.z);
    }

    void initTrajectoryMarker()
    {
        trajectory_marker_.header.frame_id = "world";
        trajectory_marker_.header.stamp = ros::Time::now();
        trajectory_marker_.ns = "imu_trajectory";
        trajectory_marker_.id = 0;
        trajectory_marker_.type = visualization_msgs::Marker::LINE_STRIP;
        trajectory_marker_.action = visualization_msgs::Marker::ADD;
        trajectory_marker_.scale.x = 0.02;
        trajectory_marker_.color.r = 1.0f;
        trajectory_marker_.color.g = 0.0f;
        trajectory_marker_.color.b = 0.0f;
        trajectory_marker_.color.a = 1.0;
        trajectory_marker_.lifetime = ros::Duration();
    }

    void imuCallback(const sensor_msgs::Imu::ConstPtr& msg)
    {
        // 异常值检测
        if (std::abs(msg->angular_velocity.x) > 5.0 || std::abs(msg->angular_velocity.y) > 5.0 || std::abs(msg->angular_velocity.z) > 5.0 ||
            std::abs(msg->linear_acceleration.x) > 20.0 || std::abs(msg->linear_acceleration.y) > 20.0 || std::abs(msg->linear_acceleration.z) > 20.0) {
            ROS_WARN("IMU data out of range, skipping");
            return;
        }
        
        if (!first_msg_received_) {
            last_time_ = msg->header.stamp;
            first_msg_received_ = true;
            
            // 如果开启了初始强制零速检测，记录开始时间并设置标志
            if (enable_initial_zupt_) {
                initial_zupt_start_time_ = msg->header.stamp;
                is_in_initial_zupt_ = true;
                ROS_INFO("Initial ZUPT enabled, duration: %.1f seconds", initial_zupt_duration_);
            }
            
            return;
        }

        // 计算时间差
        double dt = (msg->header.stamp - last_time_).toSec();
        last_time_ = msg->header.stamp;
        
        // 限制时间间隔，避免积分误差过大
        if (dt <= time_interval_min_ || dt > time_interval_max_) {
            ROS_WARN("Invalid time interval: %f, skipping this measurement", dt);
            return;
        }

        // 获取IMU数据
        geometry_msgs::Vector3 accel = msg->linear_acceleration;
        geometry_msgs::Vector3 gyro = msg->angular_velocity;
        
        // 收集前N帧数据计算重力向量
        if (!gravity_calculated_) {
            collectGravityData(accel);
            return;  // 还在收集数据阶段，不进行轨迹计算
        }
        
        // 初始强制零速检测
        if (is_in_initial_zupt_) {
            // 检查初始强制零速检测是否结束
            if ((msg->header.stamp - initial_zupt_start_time_).toSec() > initial_zupt_duration_) {
                is_in_initial_zupt_ = false;
                ROS_INFO("Initial ZUPT completed");
            } else {
                // 强制零速
                linear_velocity_.x = 0;
                linear_velocity_.y = 0;
                linear_velocity_.z = 0;
                
                // 同时重置ESKF的速度误差协方差
                if (filter_type_ == "eskf") {
                    P_.block<3,3>(3,3) *= zupt_cov_reduction_factor_; // 减小速度误差协方差
                }
            }
        }
        // 普通零速检测（ZUPT）
        else if ((std::abs(accel.x) < zupt_accel_threshold_ && std::abs(accel.y) < zupt_accel_threshold_ ||  
            std::abs(accel.z - calculated_gravity_) < zupt_accel_z_threshold_ )||
            std::abs(gyro.x) < zupt_gyro_threshold_ && std::abs(gyro.y) < zupt_gyro_threshold_ && std::abs(gyro.z) < zupt_gyro_threshold_) {
            // 增加连续零速帧数
            consecutive_zupt_frames_++;
            
            // 零速时重置速度和修正位置
            linear_velocity_.x = 0;
            linear_velocity_.y = 0;
            linear_velocity_.z = 0;
            
            // 同时可以重置ESKF的速度误差协方差
            if (filter_type_ == "eskf") {
                P_.block<3,3>(3,3) *= zupt_cov_reduction_factor_; // 减小速度误差协方差
            }
            
            // 检查是否达到触发重力重新计算的阈值
            if (gravity_mode_ == "auto" && 
                consecutive_zupt_frames_ >= zupt_gravity_calibration_threshold_) {
                // 重置重力校准相关变量
                gravity_calculated_ = false;
                gravity_calibration_count_ = 0;
                accel_sum_.x = 0.0;
                accel_sum_.y = 0.0;
                accel_sum_.z = 0.0;
                
                ROS_INFO("ZUPT triggered gravity recalculation");
                
                // 重置连续零速帧数
                consecutive_zupt_frames_ = 0;
            }
        } else {
            // 非零速时，重置连续零速帧数
            consecutive_zupt_frames_ = 0;
        }
        
        // 根据滤波器类型选择处理方法
        if (filter_type_ == "eskf") {
            // 使用ESKF进行状态预测和更新
            eskfPredict(gyro, accel, dt);
            eskfUpdate(gyro, accel);
        } else {
            // 使用原来的滑动窗口滤波方法
            // 应用滑动窗口滤波和偏置补偿
            geometry_msgs::Vector3 gyro_compensated = slidingWindowFilter(gyro, gyro_window_, gyro_bias_);
            geometry_msgs::Vector3 accel_compensated = slidingWindowFilter(accel, accel_window_, accel_bias_);

            // 更新姿态 (使用四元数积分)
            updateOrientation(gyro_compensated, dt);

            // 将加速度从IMU坐标系转换到世界坐标系，但在IMU坐标系中先减去重力
            tf2::Vector3 accel_imu(accel_compensated.x, accel_compensated.y, accel_compensated.z);
            
            // 发布加速度向量可视化（减去重力之前）
            publishAccelVectorMarker(accel_imu);
            
            // 减去重力加速度 (在IMU坐标系中进行)
            subtractGravity(accel_imu);
            
            // 发布减去重力后的加速度向量可视化
            publishAccelVectorNoGravityMarker(accel_imu);
            
            // 将加速度从IMU坐标系转换到世界坐标系
            tf2::Matrix3x3 orientation_mat(current_orientation_);
            tf2::Vector3 accel_world = orientation_mat * accel_imu;

            // 更新速度 (积分加速度)
            linear_velocity_.x += accel_world.x() * dt;
            linear_velocity_.y += accel_world.y() * dt;
            linear_velocity_.z += accel_world.z() * dt;

            // 更新位置 (积分速度)
            current_position_.x += linear_velocity_.x * dt;
            current_position_.y += linear_velocity_.y * dt;
            current_position_.z += linear_velocity_.z * dt;
        }

        // 更新轨迹标记
        geometry_msgs::Point p;
        p.x = current_position_.x;
        p.y = current_position_.y;
        p.z = current_position_.z;
        trajectory_marker_.points.push_back(p);

        // 发布轨迹标记
        trajectory_marker_.header.stamp = msg->header.stamp;
        marker_pub_.publish(trajectory_marker_);

        // 发布TF变换
        publishTF(msg->header.stamp);
    }
    

    
    geometry_msgs::Vector3 slidingWindowFilter(const geometry_msgs::Vector3& data, 
                                             std::deque<geometry_msgs::Vector3>& window, 
                                             const geometry_msgs::Vector3& bias)
    {
        // 将新数据加入窗口
        window.push_back(data);
        
        // 保持窗口大小
        if (window.size() > window_size_) {
            window.pop_front();
        }
        
        // 计算窗口内的平均值
        double sum_x = 0.0, sum_y = 0.0, sum_z = 0.0;
        int current_size = window.size();
        
        // 根据权重类型计算加权平均
        if (weight_type_ == "equal" || current_size <= 1) {
            // 等权重平均
            for (const auto& sample : window) {
                sum_x += sample.x;
                sum_y += sample.y;
                sum_z += sample.z;
            }
        } else if (weight_type_ == "exponential") {
            // 完整的指数加权移动平均 (EWMA) 实现
            double alpha = 0.2; // 平滑因子，0 < alpha < 1，值越大越重视新数据
            if (current_size == 1) {
                // 窗口中只有一个数据点时，直接使用该数据
                sum_x = window[0].x;
                sum_y = window[0].y;
                sum_z = window[0].z;
            } else {
                // 从窗口中获取最新数据
                geometry_msgs::Vector3 latest_data = window.back();
                // 应用EWMA公式：EWMA_t = alpha * x_t + (1 - alpha) * EWMA_{t-1}
                sum_x = alpha * latest_data.x + (1 - alpha) * sum_x;
                sum_y = alpha * latest_data.y + (1 - alpha) * sum_y;
                sum_z = alpha * latest_data.z + (1 - alpha) * sum_z;
            }
        } else if (weight_type_ == "gaussian") {
            // 高斯加权平均
            // 计算每个样本的高斯权重，中心样本权重最高
            double total_weight = 0.0;
            double weights[current_size];
            int center = current_size / 2;
            
            // 计算每个样本的权重
            for (int i = 0; i < current_size; i++) {
                int distance = i - center;
                weights[i] = exp(-(distance * distance) / (2 * gaussian_sigma_ * gaussian_sigma_));
                total_weight += weights[i];
            }
            
            // 归一化权重并计算加权和
            for (int i = 0; i < current_size; i++) {
                double normalized_weight = weights[i] / total_weight;
                sum_x += window[i].x * normalized_weight;
                sum_y += window[i].y * normalized_weight;
                sum_z += window[i].z * normalized_weight;
            }
        } else {
            // 默认使用等权重平均
            for (const auto& sample : window) {
                sum_x += sample.x;
                sum_y += sample.y;
                sum_z += sample.z;
            }
        }
        
        geometry_msgs::Vector3 filtered;
        
        if (weight_type_ == "exponential" && current_size > 1) {
            // 指数加权平均不需要除以样本数
            filtered.x = sum_x - bias.x;
            filtered.y = sum_y - bias.y;
            filtered.z = sum_z - bias.z;
        } else if (weight_type_ == "gaussian" && current_size > 1) {
            // 高斯加权平均已经归一化，不需要除以样本数
            filtered.x = sum_x - bias.x;
            filtered.y = sum_y - bias.y;
            filtered.z = sum_z - bias.z;
        } else {
            // 等权重平均需要除以样本数
            filtered.x = (sum_x / current_size) - bias.x;
            filtered.y = (sum_y / current_size) - bias.y;
            filtered.z = (sum_z / current_size) - bias.z;
        }
        
        return filtered;
    }
    
    void updateOrientation(const geometry_msgs::Vector3& gyro, double dt)
    {
        // 使用四元数积分更新姿态 (一阶龙格-库塔)
        tf2::Quaternion delta_q;
        double theta = sqrt(gyro.x*gyro.x + gyro.y*gyro.y + gyro.z*gyro.z) * dt;
        
        if (theta > 1e-6) {
            double sin_theta_2 = sin(theta / 2.0);
            double cos_theta_2 = cos(theta / 2.0);
            
            delta_q.setX(gyro.x * sin_theta_2 * dt / theta);
            delta_q.setY(gyro.y * sin_theta_2 * dt / theta);
            delta_q.setZ(gyro.z * sin_theta_2 * dt / theta);
            delta_q.setW(cos_theta_2);
        } else {
            // 小角度近似
            delta_q.setX(gyro.x * dt / 2.0);
            delta_q.setY(gyro.y * dt / 2.0);
            delta_q.setZ(gyro.z * dt / 2.0);
            delta_q.setW(1.0);
        }
        
        current_orientation_ *= delta_q;
        current_orientation_.normalize();
    }
    
    void collectGravityData(const geometry_msgs::Vector3& accel) {
        // 根据重力模式选择处理方式
        if (gravity_mode_ == "manual") {
            // 使用手动设置的重力值
            calculated_gravity_ = manual_gravity_;
            gravity_calculated_ = true;
            
            // 计算初始旋转矩阵R_wi（IMU到世界坐标系），将IMU矫正到水平
            // 重力向量在IMU坐标系中为 [avg_x, avg_y, avg_z]
            // 我们希望在世界坐标系中，重力向量沿Z轴向下，即 [0, 0, -calculated_gravity_]
            
            // 计算旋转轴（两个向量的叉积）
            tf2::Vector3 gravity_imu(accel.x, accel.y, accel.z);
            tf2::Vector3 gravity_world(0.0, 0.0, calculated_gravity_); // 世界坐标系中重力沿Z轴向上
            
            tf2::Vector3 rotation_axis = gravity_imu.cross(gravity_world);
            double rotation_angle = std::acos(gravity_imu.dot(gravity_world) / (gravity_imu.length() * gravity_world.length()));
            
            // 如果旋转轴长度为0，说明IMU已经水平，不需要旋转
            if (rotation_axis.length() > 1e-6) {
                rotation_axis.normalize();
                
                // 创建旋转四元数
                tf2::Quaternion rotation_quat;
                rotation_quat.setRotation(rotation_axis, rotation_angle);
                
                // 设置当前姿态为初始旋转矩阵
                current_orientation_ = rotation_quat;
                current_orientation_.normalize();
            }
            
            ROS_INFO("Using manual gravity value!");
            ROS_INFO("Manual gravity: %.6f m/s^2", calculated_gravity_);
            ROS_INFO("Initial IMU orientation calibrated to level");
        } else {
            // 自动模式：累加加速度计读数
            accel_sum_.x += accel.x;
            accel_sum_.y += accel.y;
            accel_sum_.z += accel.z;
            gravity_calibration_count_++;
            
            // 检查是否收集了足够的样本
            if (gravity_calibration_count_ >= gravity_calibration_samples_) {
                // 计算平均加速度（假设静止，所以主要是重力）
                double avg_x = accel_sum_.x / gravity_calibration_count_;
                double avg_y = accel_sum_.y / gravity_calibration_count_;
                double avg_z = accel_sum_.z / gravity_calibration_count_;
                
                // 计算重力大小
                calculated_gravity_ = std::sqrt(avg_x * avg_x + avg_y * avg_y + avg_z * avg_z);
                
                // 计算初始旋转矩阵R_wi（IMU到世界坐标系），将IMU矫正到水平
                // 重力向量在IMU坐标系中为 [avg_x, avg_y, avg_z]
                // 我们希望在世界坐标系中，重力向量沿Z轴向下，即 [0, 0, -calculated_gravity_]
                
                // 计算旋转轴（两个向量的叉积）
                tf2::Vector3 gravity_imu(avg_x, avg_y, avg_z);
                tf2::Vector3 gravity_world(0.0, 0.0, calculated_gravity_); // 世界坐标系中重力沿Z轴向上
                
                tf2::Vector3 rotation_axis = gravity_imu.cross(gravity_world);
                double rotation_angle = std::acos(gravity_imu.dot(gravity_world) / (gravity_imu.length() * gravity_world.length()));
                
                // 如果旋转轴长度为0，说明IMU已经水平，不需要旋转
                if (rotation_axis.length() > 1e-6) {
                    rotation_axis.normalize();
                    
                    // 创建旋转四元数
                    tf2::Quaternion rotation_quat;
                    rotation_quat.setRotation(rotation_axis, rotation_angle);
                    
                    // 检查rotation_quat的yaw是否为0，如果是则保留原有yaw
                    tf2::Matrix3x3 rotation_mat(rotation_quat);
                    double roll, pitch, yaw;
                    rotation_mat.getRPY(roll, pitch, yaw);
                    
                    if (std::abs(yaw) < 100) {  // 如果yaw接近0
                        // 从当前姿态中提取原有的yaw
                        tf2::Matrix3x3 current_mat(current_orientation_);
                        double current_roll, current_pitch, current_yaw;
                        current_mat.getRPY(current_roll, current_pitch, current_yaw);
                        
                        // 创建一个新的四元数，应用rotation_quat的roll和pitch，加上原有的yaw
                        tf2::Quaternion new_quat;
                        new_quat.setRPY(roll, pitch, current_yaw);
                        current_orientation_ = new_quat;
                    } else {
                        // 否则直接使用rotation_quat
                        current_orientation_ = rotation_quat;
                    }
                    
                    current_orientation_.normalize();
                }
                
                gravity_calculated_ = true;
                
                ROS_INFO("Gravity calibration completed!");
                ROS_INFO("Calculated gravity: %.6f m/s^2", calculated_gravity_);
                ROS_INFO("Initial IMU orientation calibrated to level");
            } else if (gravity_calibration_count_ % 10 == 0) {
                ROS_INFO("Collecting gravity data: %d/%d samples", 
                         gravity_calibration_count_, gravity_calibration_samples_);
            }
        }
    }
    
    void subtractGravity(tf2::Vector3& accel_imu)
    {
        // 将重力向量从世界坐标系变换到IMU坐标系
        // 重力在世界坐标系中沿Z轴向下
        tf2::Vector3 gravity_world(0.0, 0.0, calculated_gravity_);
        
        // 获取当前IMU到世界坐标系的旋转矩阵
        tf2::Matrix3x3 orientation_mat(current_orientation_);
        
        // 计算世界坐标系到IMU坐标系的旋转矩阵（转置）
        tf2::Matrix3x3 world_to_imu_mat = orientation_mat.transpose();
        
        // 将重力向量从世界坐标系变换到IMU坐标系
        tf2::Vector3 gravity_imu = world_to_imu_mat * gravity_world;
        
        // 发布重力向量可视化
        publishGravityVectorMarker(gravity_imu);
        
        // 从加速度计测量结果中减去IMU坐标系下的重力向量
        accel_imu -= gravity_imu;
    }
    
    void publishGravityVectorMarker(const tf2::Vector3& gravity_imu)
    {
        visualization_msgs::Marker marker;
        marker.header.frame_id = "imu_link";
        marker.header.stamp = ros::Time::now();
        marker.ns = "gravity_vector";
        marker.id = 0;
        marker.type = visualization_msgs::Marker::ARROW;
        marker.action = visualization_msgs::Marker::ADD;
        
        // 设置箭头起点（IMU原点）
        marker.pose.position.x = 0.0;
        marker.pose.position.y = 0.0;
        marker.pose.position.z = 0.0;
        
        // 直接初始化四元数为单位四元数（避免Uninitialized quaternion错误）
        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;
        
        // 计算箭头方向
        tf2::Vector3 arrow_direction = -gravity_imu.normalized();
        
        // 计算箭头的旋转（从x轴指向重力向量方向）
        tf2::Vector3 x_axis(1.0, 0.0, 0.0);
        
        // 检查是否需要旋转
        double dot_product = x_axis.dot(arrow_direction);
        printf("arrow_direction_gravity: (%.6f, %.6f, %.6f)\n", arrow_direction.x(), arrow_direction.y(), arrow_direction.z());
        printf("dot_product: %.6f\n", dot_product);
        if (fabs(dot_product - 1.0) > 1e-6) {  // 不是同一方向
            if (fabs(dot_product + 1.0) < 1e-6) {  // 完全相反方向
                // 绕x轴旋转180度
                tf2::Quaternion rotation;
                rotation.setRPY(M_PI, 0.0, 0.0);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            } else {
                // 正常情况：计算旋转轴和旋转角
                tf2::Vector3 rotation_axis = x_axis.cross(arrow_direction);
                double rotation_angle = acos(dot_product);
                tf2::Quaternion rotation;
                rotation.setRotation(rotation_axis, rotation_angle);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            }
        }
        
        // 设置箭头缩放
        marker.scale.x = gravity_imu.length();  // 箭头长度等于重力向量长度
        marker.scale.y = 0.01;  // 箭头宽度
        marker.scale.z = 0.01;  // 箭头高度
        
        // 设置箭头颜色（红色）
        marker.color.r = 1.0;
        marker.color.g = 0.0;
        marker.color.b = 0.0;
        marker.color.a = 1.0;
        
        // 设置标记持续时间
        marker.lifetime = ros::Duration(0.1);
        
        // 发布标记
        gravity_vector_pub_.publish(marker);
    }
    
    // 发布加速度向量可视化标记
    void publishAccelVectorMarker(const tf2::Vector3& accel_imu)
    {
        visualization_msgs::Marker marker;
        marker.header.frame_id = "imu_link";
        marker.header.stamp = ros::Time::now();
        marker.ns = "accel_vector";
        marker.id = 0;
        marker.type = visualization_msgs::Marker::ARROW;
        marker.action = visualization_msgs::Marker::ADD;
        
        // 设置箭头起点（IMU原点）
        marker.pose.position.x = 0.0;
        marker.pose.position.y = 0.0;
        marker.pose.position.z = 0.0;
        
        // 直接初始化四元数为单位四元数（避免Uninitialized quaternion错误）
        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;
        
        // 计算箭头方向
        tf2::Vector3 arrow_direction = accel_imu.normalized();
        
        // 计算箭头的旋转（从z轴指向加速度向量方向）
        tf2::Vector3 z_axis(1.0, 0.0, 0);
        
        // 检查是否需要旋转
        double dot_product = z_axis.dot(arrow_direction);
        if (fabs(dot_product - 1.0) > 1e-6) {  // 不是同一方向
            if (fabs(dot_product + 1.0) < 1e-6) {  // 完全相反方向
                // 绕x轴旋转180度
                tf2::Quaternion rotation;
                rotation.setRPY(M_PI, 0.0, 0.0);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            } else {
                // 正常情况：计算旋转轴和旋转角
                tf2::Vector3 rotation_axis = z_axis.cross(arrow_direction);
                double rotation_angle = acos(dot_product);
                tf2::Quaternion rotation;
                rotation.setRotation(rotation_axis, rotation_angle);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            }
        }
        
        // 设置箭头缩放
        marker.scale.x = accel_imu.length();  // 箭头长度等于加速度向量长度
        marker.scale.y = 0.01;  // 箭头宽度
        marker.scale.z = 0.01;  // 箭头高度
        
        // 设置箭头颜色（蓝色）
        marker.color.r = 0.0;
        marker.color.g = 0.0;
        marker.color.b = 1.0;
        marker.color.a = 1.0;
        
        // 设置标记持续时间
        marker.lifetime = ros::Duration(0.1);
        
        // 发布标记
        accel_vector_pub_.publish(marker);
    }
    
    // 发布减去重力后的加速度向量标记
    void publishAccelVectorNoGravityMarker(const tf2::Vector3& accel_imu_no_gravity) {
        visualization_msgs::Marker marker;
        marker.header.frame_id = "imu_link";
        marker.header.stamp = ros::Time::now();
        marker.ns = "accel_vector_no_gravity";
        marker.id = 0;
        marker.type = visualization_msgs::Marker::ARROW;
        marker.action = visualization_msgs::Marker::ADD;
        
        // 设置箭头起点（IMU原点）
        marker.pose.position.x = 0.0;
        marker.pose.position.y = 0.0;
        marker.pose.position.z = 0.0;
        
        // 直接初始化四元数为单位四元数（避免Uninitialized quaternion错误）
        marker.pose.orientation.x = 0.0;
        marker.pose.orientation.y = 0.0;
        marker.pose.orientation.z = 0.0;
        marker.pose.orientation.w = 1.0;
        
        // 计算箭头方向
        tf2::Vector3 arrow_direction;
        if (accel_imu_no_gravity.length() > 1e-6) {
            arrow_direction = accel_imu_no_gravity.normalized();
        } else {
            arrow_direction = tf2::Vector3(0.0, 0.0, 0.0); // 零向量时默认指向z轴
        }
        printf("arrow_direction_accel_imu_no_gravity: (%f, %f, %f)\n", arrow_direction.x(), arrow_direction.y(), arrow_direction.z());
        // 计算箭头的旋转（从z轴指向加速度向量方向）
        tf2::Vector3 z_axis(1.0, 0.0, 0);
        
        // 检查是否需要旋转
        double dot_product = z_axis.dot(arrow_direction);
        if (fabs(dot_product - 1.0) > 1e-6) {  // 不是同一方向
            if (fabs(dot_product + 1.0) < 1e-6) {  // 完全相反方向
                // 绕x轴旋转180度
                tf2::Quaternion rotation;
                rotation.setRPY(M_PI, 0.0, 0.0);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            } else {
                // 正常情况：计算旋转轴和旋转角
                tf2::Vector3 rotation_axis = z_axis.cross(arrow_direction);
                double rotation_angle = acos(dot_product);
                tf2::Quaternion rotation;
                rotation.setRotation(rotation_axis, rotation_angle);
                marker.pose.orientation.x = rotation.x();
                marker.pose.orientation.y = rotation.y();
                marker.pose.orientation.z = rotation.z();
                marker.pose.orientation.w = rotation.w();
            }
        }
        
        // 设置箭头缩放
        marker.scale.x = accel_imu_no_gravity.length();  // 箭头长度等于加速度向量长度
        marker.scale.y = 0.01;  // 箭头宽度
        marker.scale.z = 0.01;  // 箭头高度
        
        // 设置箭头颜色（绿色）
        marker.color.r = 0.0;
        marker.color.g = 1.0;
        marker.color.b = 0.0;
        marker.color.a = 1.0;
        
        // 设置标记持续时间
        marker.lifetime = ros::Duration(0.1);
        
        // 发布标记
        accel_vector_no_gravity_pub_.publish(marker);
    }
    
    // ESKF预测步骤
    void eskfPredict(const geometry_msgs::Vector3& gyro, const geometry_msgs::Vector3& accel, double dt)
    {
        // 1. 更新姿态 (使用四元数积分)
        tf2::Quaternion delta_q;
        double theta = sqrt(gyro.x*gyro.x + gyro.y*gyro.y + gyro.z*gyro.z) * dt;
        
        if (theta > 1e-6) {
            double sin_theta_2 = sin(theta / 2.0);
            double cos_theta_2 = cos(theta / 2.0);
            
            delta_q.setX(gyro.x * sin_theta_2 * dt / theta);
            delta_q.setY(gyro.y * sin_theta_2 * dt / theta);
            delta_q.setZ(gyro.z * sin_theta_2 * dt / theta);
            delta_q.setW(cos_theta_2);
        } else {
            // 小角度近似
            delta_q.setX(gyro.x * dt / 2.0);
            delta_q.setY(gyro.y * dt / 2.0);
            delta_q.setZ(gyro.z * dt / 2.0);
            delta_q.setW(1.0);
        }
        
        current_orientation_ *= delta_q;
        current_orientation_.normalize();
        
        // 2. 将加速度从IMU坐标系转换到世界坐标系，并减去重力
        tf2::Matrix3x3 orientation_mat(current_orientation_);
        tf2::Vector3 accel_imu(accel.x - accel_bias_.x, accel.y - accel_bias_.y, accel.z - accel_bias_.z);
        
        // 发布加速度向量可视化
        publishAccelVectorMarker(accel_imu);
        
        // 在IMU坐标系中创建减去重力后的加速度向量
        tf2::Vector3 gravity_world(0.0, 0.0, calculated_gravity_);
        tf2::Vector3 gravity_imu = orientation_mat.inverse() * gravity_world;
        tf2::Vector3 accel_imu_no_gravity = accel_imu - gravity_imu;
        
        // 发布减去重力后的加速度向量可视化
        publishAccelVectorNoGravityMarker(accel_imu_no_gravity);
        
        tf2::Vector3 accel_world = orientation_mat * accel_imu;
        accel_world -= gravity_world;
        
        // 3. 更新速度
        linear_velocity_.x += accel_world.x() * dt;
        linear_velocity_.y += accel_world.y() * dt;
        linear_velocity_.z += accel_world.z() * dt;
        
        // 4. 更新位置
        current_position_.x += linear_velocity_.x * dt;
        current_position_.y += linear_velocity_.y * dt;
        current_position_.z += linear_velocity_.z * dt;
        
        // 5. 更新误差状态协方差矩阵 P
        // 构建状态转移矩阵 F
        Eigen::MatrixXd F = Eigen::MatrixXd::Identity(15, 15);
        
        // 姿态误差的雅可比矩阵（简化版）
        Eigen::Matrix3d I3 = Eigen::Matrix3d::Identity();
        Eigen::Matrix3d Omega = Eigen::Matrix3d::Zero();
        Omega << 0, -gyro.z, gyro.y,
                 gyro.z, 0, -gyro.x,
                 -gyro.y, gyro.x, 0;
        Eigen::Matrix3d exp_Omega_dt = I3 + Omega * dt;
        
        // 填充 F 矩阵
        F.block<3,3>(6,6) = exp_Omega_dt;
        F.block<3,3>(0,3) = I3 * dt;
        
        // 加速度对姿态误差的雅可比
        Eigen::Matrix3d acc_skew;
        acc_skew << 0, -accel_world.z(), accel_world.y(),
                    accel_world.z(), 0, -accel_world.x(),
                    -accel_world.y(), accel_world.x(), 0;
        
        // 将tf2::Matrix3x3转换为Eigen::Matrix3d
        Eigen::Matrix3d eigen_orientation_mat;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                eigen_orientation_mat(i, j) = orientation_mat[i][j];
            }
        }
        
        F.block<3,3>(3,6) = -eigen_orientation_mat * acc_skew * dt;
        
        // 构建过程噪声协方差矩阵 Q（核心修改：分轴对角矩阵，替代原标量单位矩阵）
        Eigen::MatrixXd Q = Eigen::MatrixXd::Zero(15, 15);
        // 陀螺仪测量噪声（姿态误差部分，第6-8行/列）：分轴填入gyr_n
        Q(6,6) = gyr_n_[0] * dt;
        Q(7,7) = gyr_n_[1] * dt;
        Q(8,8) = gyr_n_[2] * dt;
        // 陀螺仪偏置随机游走噪声（陀螺仪偏置误差部分，第9-11行/列）：分轴填入gyr_w
        Q(9,9) = gyr_w_[0] * dt;
        Q(10,10) = gyr_w_[1] * dt;
        Q(11,11) = gyr_w_[2] * dt;
        // 加速度计偏置随机游走噪声（加速度计偏置误差部分，第12-14行/列）：分轴填入acc_w
        Q(12,12) = acc_w_[0] * dt;
        Q(13,13) = acc_w_[1] * dt;
        Q(14,14) = acc_w_[2] * dt;
        
        // 更新协方差矩阵：P = F * P * F^T + Q
        P_ = F * P_ * F.transpose() + Q;
        
        // 保持协方差矩阵的对称性
        P_ = (P_ + P_.transpose()) / 2.0;
    }
    
    // ESKF更新步骤（带有自适应噪声协方差调整）
    void eskfUpdate(const geometry_msgs::Vector3& gyro, const geometry_msgs::Vector3& accel)
    {
        // 1. 构建测量矩阵 H
        Eigen::MatrixXd H = Eigen::MatrixXd::Zero(6, 15);
        
        // 陀螺仪测量对姿态误差和陀螺仪偏置误差的敏感
        H.block<3,3>(0,6) = Eigen::Matrix3d::Identity();
        H.block<3,3>(0,9) = Eigen::Matrix3d::Identity();
        
        // 加速度计测量对姿态误差和加速度计偏置误差的敏感
        tf2::Matrix3x3 orientation_mat(current_orientation_);
        tf2::Vector3 accel_imu(accel.x - accel_bias_.x, accel.y - accel_bias_.y, accel.z - accel_bias_.z);
        tf2::Vector3 accel_world = orientation_mat * accel_imu;
        accel_world -= tf2::Vector3(0.0, 0.0, calculated_gravity_);
        
        // 将tf2::Matrix3x3转换为Eigen::Matrix3d
        Eigen::Matrix3d eigen_orientation_mat;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                eigen_orientation_mat(i, j) = orientation_mat[i][j];
            }
        }
        
        Eigen::Matrix3d acc_skew;
        acc_skew << 0, -accel_world.z(), accel_world.y(),
                    accel_world.z(), 0, -accel_world.x(),
                    -accel_world.y(), accel_world.x(), 0;
        H.block<3,3>(3,6) = -eigen_orientation_mat * acc_skew;
        H.block<3,3>(3,12) = -eigen_orientation_mat;
        
        // 2. 构建测量噪声协方差矩阵 R（核心修改：分轴对角矩阵）
        Eigen::MatrixXd R = Eigen::MatrixXd::Zero(6, 6);
        // 陀螺仪测量噪声（前3行/列）：分轴填入r_gyr_
        R(0,0) = r_gyr_[0];
        R(1,1) = r_gyr_[1];
        R(2,2) = r_gyr_[2];
        // 加速度计测量噪声（后3行/列）：分轴填入r_acc_
        R(3,3) = r_acc_[0];
        R(4,4) = r_acc_[1];
        R(5,5) = r_acc_[2];
        
        // 3. 计算新息 (innovation)
        Eigen::VectorXd z_meas(6);
        z_meas << gyro.x, gyro.y, gyro.z,
                  accel.x, accel.y, accel.z;
        
        Eigen::VectorXd z_pred(6);
        z_pred << 0, 0, 0, 0, 0, calculated_gravity_; // 简化的预测测量值
        
        Eigen::VectorXd innovation = z_meas - z_pred;
        
        // 4. 计算新息协方差 S = H * P * H^T + R
        Eigen::MatrixXd S = H * P_ * H.transpose() + R;
        
        // 5. 自适应调整测量噪声协方差（核心修改：分轴独立调整，替代原标量调整）
        double innovation_norm = innovation.norm();
        if (innovation_norm > innovation_threshold_) {
            // 各轴独立增大噪声
            r_gyr_[0] *= noise_update_factor_;
            r_gyr_[1] *= noise_update_factor_;
            r_gyr_[2] *= noise_update_factor_;
            r_acc_[0] *= noise_update_factor_;
            r_acc_[1] *= noise_update_factor_;
            r_acc_[2] *= noise_update_factor_;
            ROS_DEBUG("Increasing per-axis measurement noise: innovation=%.3f > threshold=%.3f", innovation_norm, innovation_threshold_);
        } else {
            // 各轴独立减小噪声
            r_gyr_[0] *= noise_reduce_factor_;
            r_gyr_[1] *= noise_reduce_factor_;
            r_gyr_[2] *= noise_reduce_factor_;
            r_acc_[0] *= noise_reduce_factor_;
            r_acc_[1] *= noise_reduce_factor_;
            r_acc_[2] *= noise_reduce_factor_;
            ROS_DEBUG("Decreasing per-axis measurement noise: innovation=%.3f <= threshold=%.3f", innovation_norm, innovation_threshold_);
        }
        
        // 6. 计算卡尔曼增益 K = P * H^T * S^{-1}
        Eigen::MatrixXd K = P_ * H.transpose() * S.inverse();
        
        // 7. 更新误差状态
        Eigen::VectorXd delta_x = K * innovation;
        
        // 8. 应用误差状态校正到标称状态
        // 位置校正
        current_position_.x += delta_x(0);
        current_position_.y += delta_x(1);
        current_position_.z += delta_x(2);
        
        // 速度校正
        linear_velocity_.x += delta_x(3);
        linear_velocity_.y += delta_x(4);
        linear_velocity_.z += delta_x(5);
        
        // 姿态校正（使用四元数）
        tf2::Vector3 delta_theta(delta_x(6), delta_x(7), delta_x(8));
        double theta_mag = delta_theta.length();
        tf2::Quaternion delta_q;
        if (theta_mag > 1e-6) {
            delta_q.setRotation(delta_theta, theta_mag);
        } else {
            delta_q.setX(delta_theta.x() / 2.0);
            delta_q.setY(delta_theta.y() / 2.0);
            delta_q.setZ(delta_theta.z() / 2.0);
            delta_q.setW(1.0);
        }
        current_orientation_ *= delta_q;
        current_orientation_.normalize();
        
        // 陀螺仪偏置校正
        gyro_bias_.x += delta_x(9);
        gyro_bias_.y += delta_x(10);
        gyro_bias_.z += delta_x(11);
        
        // 加速度计偏置校正
        accel_bias_.x += delta_x(12);
        accel_bias_.y += delta_x(13);
        accel_bias_.z += delta_x(14);
        
        // 9. 更新协方差矩阵 P = (I - K * H) * P * (I - K * H)^T + K * R * K^T
        Eigen::MatrixXd I = Eigen::MatrixXd::Identity(15, 15);
        P_ = (I - K * H) * P_ * (I - K * H).transpose() + K * R * K.transpose();
        
        // 保持协方差矩阵的对称性
        P_ = (P_ + P_.transpose()) / 2.0;
    }
    
    void publishTF(const ros::Time& stamp)
    {
        geometry_msgs::TransformStamped transformStamped;

        transformStamped.header.stamp = stamp;
        transformStamped.header.frame_id = "world";
        transformStamped.child_frame_id = "imu_link";

        transformStamped.transform.translation.x = current_position_.x;
        transformStamped.transform.translation.y = current_position_.y;
        transformStamped.transform.translation.z = current_position_.z;

        transformStamped.transform.rotation.x = current_orientation_.x();
        transformStamped.transform.rotation.y = current_orientation_.y();
        transformStamped.transform.rotation.z = current_orientation_.z();
        transformStamped.transform.rotation.w = current_orientation_.w();

        tf_broadcaster_.sendTransform(transformStamped);
    }
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "imu_trajectory_node");
    ImuTrajectory imu_trajectory;
    ros::spin();
    return 0;
}